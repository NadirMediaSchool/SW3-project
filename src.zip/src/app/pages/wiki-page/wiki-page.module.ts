import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { WikiPageComponent } from './wiki-page.component';
import { HttpClientModule } from '@angular/common/http';
import { SearchModule } from 'src/app/components/search/search.module';

@NgModule({
  declarations: [WikiPageComponent],
  imports: [
    CommonModule,
    RouterModule.forChild([{ path: '', component: WikiPageComponent }]),
    HttpClientModule,
    SearchModule
  ]
})
export class WikiPageModule {}