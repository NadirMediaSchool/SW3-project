
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-wiki-page',
  templateUrl: './wiki-page.component.html',
  styleUrls: ['./wiki-page.component.css']
})
export class WikiPageComponent implements OnInit {
  query: string = '';
  extract: string = '';
  errorMessage: string = '';

  constructor(private route: ActivatedRoute, private http: HttpClient) {}

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.query = params['query'];
      this.searchWiki();
    });
  }

  onSearch(query: string) {
    this.query = query;
    this.searchWiki();
  }

  searchWiki() {
    const apiUrl = `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(this.query)}`;
    this.http.get(apiUrl).subscribe((data: any) => {
      if (data.extract) {
        this.extract = data.extract;
        this.errorMessage = '';
      } else {
        this.errorMessage = 'Aucune définition trouvée';
      }
    }, () => {
      this.errorMessage = 'Aucune définition trouvée';
    });
  }
}