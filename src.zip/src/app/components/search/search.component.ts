import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent {
  query: string = '';
  @Output() search = new EventEmitter<string>();
  errorMessage: string = '';

  onSearch() {
    if (this.query.trim()) {
      this.errorMessage = '';
      this.search.emit(this.query);
    } else {
      this.errorMessage = 'Veuillez entrer un terme de recherche';
    }
  }
}