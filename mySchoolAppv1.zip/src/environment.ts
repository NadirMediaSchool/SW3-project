export const environment = {
    production: false,
    firebase: {
      apiKey: "AIzaSyAFeJn6E_nZjr07JTo_sNKktVsVkDejdt0",
      authDomain: "mymediaschoolapp.firebaseapp.com",
      projectId: "mymediaschoolapp",
      storageBucket: "mymediaschoolapp.firebasestorage.app",
      messagingSenderId: "855345351058",
      appId: "1:855345351058:web:a2d0a8a02f6b21329b594b"
    }
  };
  