import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter, withEnabledBlockingInitialNavigation } from '@angular/router';
import { provideFirebaseApp, initializeApp } from '@angular/fire/app';
import { provideFirestore, getFirestore } from '@angular/fire/firestore';
import { HomeComponent } from './pages/home/home.component';
import { StudentListComponent } from './pages/student-list/student-list.component';
import { environment } from '../environment';
import { StudentEditComponent } from './pages/student-edit/student-edit.component';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideFirebaseApp(() => initializeApp(environment.firebase)),
    provideFirestore(() => getFirestore()),
    provideRouter([
      { path: '', component: HomeComponent },
      { path: 'student-list', component: StudentListComponent },
      { path: 'student-edit', component: StudentEditComponent },
      { path: 'student-edit/:id', component: StudentEditComponent },
      { path: '**', redirectTo: '' }
    ], withEnabledBlockingInitialNavigation())
  ]
};
