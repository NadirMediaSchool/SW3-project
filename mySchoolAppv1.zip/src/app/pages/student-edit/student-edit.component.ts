import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, RouterModule, ActivatedRoute } from '@angular/router';
import { Firestore, collection, doc, getDoc, addDoc, updateDoc } from '@angular/fire/firestore';
import { NgbDatepickerModule } from '@ng-bootstrap/ng-bootstrap';

export interface Student {
  id?: string;
  last_name: string;
  first_name: string;
  gender: string;
  date_of_birth: string;
  birth_city: string;
  address: string;
  class: string;
  guardian_name: string;
}

@Component({
  selector: 'app-student-edit',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule, NgbDatepickerModule],
  templateUrl: './student-edit.component.html',
  styleUrl: './student-edit.component.scss'
})
export class StudentEditComponent {
  studentForm: FormGroup;
  isEditMode = false;
  studentId: string | null = null;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private firestore: Firestore
  ) {
    this.studentForm = this.fb.group({
      last_name: ['', Validators.required],
      first_name: ['', Validators.required],
      birth_city: [''],
      address: [''],
      class: [''],
      guardian_name: [''],
      gender: [''],
      // Pour le datepicker, on attend un objet au format NgbDateStruct ou null
      date_of_birth: [null]
    });
  }

  async ngOnInit() {
    // Vérifie si un ID est présent dans l'URL
    this.studentId = this.route.snapshot.paramMap.get('id');
    if (this.studentId) {
      this.isEditMode = true;
      // Charger les données de l'élève depuis Firestore
      const docRef = doc(this.firestore, 'students', this.studentId);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data() as Student;
        // Convertir la date au format ISO (YYYY-MM-DD) en NgbDateStruct
        let ngbDate = null;
        if (data.date_of_birth) {
          const parts = data.date_of_birth.split('-');
          ngbDate = {
            year: +parts[0],
            month: +parts[1],
            day: +parts[2]
          };
        }
        // Alimenter le formulaire
        this.studentForm.patchValue({
          last_name: data.last_name,
          first_name: data.first_name,
          birth_city: data.birth_city,
          address: data.address,
          class: data.class,
          guardian_name: data.guardian_name,
          gender: data.gender,
          date_of_birth: ngbDate
        });
      } else {
        alert("L'élève n'existe pas.");
        this.router.navigate(['/student-list']);
      }
    }
  }

  async onSubmit() {
    if (this.studentForm.invalid) {
      return;
    }
    
    if (!confirm("Confirmez l'enregistrement de cet élève ?")) {
      return;
    }
    
    // Convertir la date (NgbDateStruct) en format ISO (YYYY-MM-DD)
    let dateISO = null;
    const dob = this.studentForm.value.date_of_birth;
    if (dob) {
      dateISO = new Date(dob.year, dob.month - 1, dob.day).toISOString().split('T')[0];
    }
    
    const studentData = {
      ...this.studentForm.value,
      date_of_birth: dateISO
    };
    
    try {
      const studentsCollection = collection(this.firestore, 'students');
      if (this.isEditMode && this.studentId) {
        // Mettre à jour l'élève existant
        const docRef = doc(this.firestore, 'students', this.studentId);
        await updateDoc(docRef, studentData);
        alert(`Utilisateur ${studentData.last_name} ${studentData.first_name} modifié avec succès`);
      } else {
        // Créer un nouvel élève
        await addDoc(studentsCollection, studentData);
        alert(`Utilisateur ${studentData.last_name} ${studentData.first_name} enregistré avec succès`);
      }
      this.router.navigate(['/student-list']);
    } catch (error) {
      console.error("Erreur lors de l'enregistrement", error);
      alert("Erreur lors de l'enregistrement de l'élève.");
    }
  }
  
  onCancel() {
    if (confirm("Annuler la modification ?")) {
      this.router.navigate(['/student-list']);
    }
  }
}
