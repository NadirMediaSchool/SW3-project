import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  Firestore,
  collectionData,
  collection,
  deleteDoc,
  doc,
  addDoc,
  getDocs
} from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { RouterModule } from '@angular/router';

interface Student {
  id?: string;
  last_name: string;
  first_name: string;
  gender: string;
  date_of_birth: string;
  birth_city: string;
  address: string;
  class: string;
  guardian_name: string;
}

@Component({
  selector: 'app-student-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './student-list.component.html',
  styleUrl: './student-list.component.scss'
})
export class StudentListComponent implements OnInit {
  students$!: Observable<Student[]>;

  constructor(private firestore: Firestore) {}

  ngOnInit(): void {
    const studentsCollection = collection(this.firestore, 'students');
    this.students$ = collectionData(studentsCollection, { idField: 'id' }) as Observable<Student[]>;
  }
  
  async onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length) {
      if (!confirm("Attention, cela écrasera les données existantes. Voulez-vous continuer ?")) {
        return;
      }
      
      const file = input.files[0];
      const reader = new FileReader();
      
      reader.onload = async (e: any) => {
        try {
          const json = JSON.parse(e.target.result);
          if (!Array.isArray(json)) {
            alert("Le fichier JSON doit contenir un tableau d'élèves.");
            return;
          }
          
          const studentsCollection = collection(this.firestore, 'students');
          const snapshot = await getDocs(studentsCollection);
          const deletions = snapshot.docs.map(docSnap =>
            deleteDoc(doc(this.firestore, 'students', docSnap.id))
          );
          await Promise.all(deletions);
          
          for (const student of json) {
            await addDoc(studentsCollection, student);
          }
          
          alert("Import réussi !");
        } catch (error) {
          console.error("Erreur lors de l'import JSON", error);
          alert("Erreur lors de l'importation du fichier JSON.");
        }
      };
      
      reader.readAsText(file);
    }
  }
}